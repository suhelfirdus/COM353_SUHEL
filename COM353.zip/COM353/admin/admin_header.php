<html>
<div class="jumbotron text-center">
            <h1>COVID-19 Tracking - Administrator </h1>
        </div>

    <!-- notification message -->


</html>
